# Physics-Informed Neural Networks for CT Reconstruction from Sparse Views

**Student:** Kolakanuru Thippeswamy · **Roll No / ID:** 48 / `20241CAI0055`

This project turns 2D chest radiographs into a controlled *synthetic* inverse problem: treat each X-ray as a 2D image, compute a parallel-beam Radon sinogram, retain a sparse subset of angles, and reconstruct the image. It compares filtered back projection (FBP) with a residual U-Net trained using measured-projection data consistency. It does **not** recover a patient's CT volume from these radiographs. The dataset contains projection-like radiographs, not CT slices or calibrated attenuation measurements; results are a methodological demonstration only.

## Dataset

- Kaggle: [Chest X-Ray Images (Pneumonia)](https://www.kaggle.com/datasets/paultimothymooney/chest-xray-pneumonia)
- The archive has `train`, `val`, and `test` directories, each with `NORMAL` and `PNEUMONIA` classes. This project uses images as 2D reference images and ignores labels for reconstruction. Keep the supplied test split held out for final metrics.
- Kaggle access may require an account and acceptance of dataset terms. Download `chest-xray-pneumonia.zip` from the Kaggle dataset page.

### Dataset setup

The supplied `archive.zip` is already extracted under `data/chest_xray/`. It contains the expected `train/`, `val/`, and `test/` folders, so training can use it directly. The archive is excluded from version control because it is large. If you later need KaggleHub instead, use the optional downloader below. Do not paste API tokens into source files or commit credentials.

```bash
python -m src.prepare_data --data-root data/chest_xray
```

Optional KaggleHub setup for a fresh machine: `python -m pip install -r requirements.txt`, then `python -m src.download_dataset --data-root data/chest_xray`.

Expected layout:

```text
project/
  data/chest_xray/{train,val,test}/{NORMAL,PNEUMONIA}/*.jpeg
```

## Setup and run

Python 3.10 or 3.11 recommended. From the project root:

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.train --data-root data/chest_xray --epochs 20 --image-size 128
python -m src.evaluate --data-root data/chest_xray --checkpoint outputs/best.pt
```

Training writes `outputs/best.pt` and `outputs/history.json`. Evaluation writes `outputs/test_metrics.json` and per-image CSV. Use `--device cpu` when needed. For a quick smoke run, use `--epochs 1 --max-train 32 --max-val 8`.

## Method

For image `x`, forward operator `A_Θ` (Radon transform at angle set Θ), and observed sparse sinogram `y=A_Θx`, estimate `x̂` by minimizing

`L(x̂,x) = λ_data L1(A_Θx̂, y) + λ_image L1(x̂, x) + λ_tv TV(x̂)`.

The differentiable projector uses a native PyTorch rotate-and-sum Radon approximation; the learned model predicts a residual correction to filtered backprojection, with data-consistency and image-space losses. Evaluation reports PSNR and SSIM against the held-out reference image and compares FBP, learned reconstruction, and sparse-angle count ablations. This is a physics-informed residual network, not an explicitly unrolled architecture or a clinical CT system.

## Report and deliverables

The deliverables are kept separate: the presentation is `deliverables/presentation/Project_Presentation.pptx`, the report and references are under `report/`, and `deliverables/Working_Model_Code_and_Results.zip` contains the runnable source, selected trained weights, epoch comparison, metrics, and reconstruction examples together. The package excludes the large dataset; place the Kaggle dataset under `data/chest_xray/` before retraining. The report records the actual reduced CPU training run and held-out metrics. Keep the dataset out of version control.

## Limitations

The chest X-ray dataset is 2D, labels/images may have source and acquisition biases, and its images are not CT attenuation slices. Parallel-beam synthetic projections, image resizing, and simplified noise differ from real scanner geometry and physics. A model trained on these images cannot establish clinical diagnostic performance or volumetric CT reconstruction. Report these constraints and propose evaluation on paired CT data and realistic geometries as future work.

## References

The completed literature review and linked sources are in [`report/REPORT.md`](report/REPORT.md) and [`report/REFERENCES.md`](report/REFERENCES.md).
